package org.globallogic.center.controller;

import java.util.ArrayList;
import java.util.List;

import org.globallogic.center.entity.Appointment;
import org.globallogic.center.entity.Diagnostic;
import org.globallogic.center.entity.DiagnosticResponse;
import org.globallogic.center.entity.Test;
import org.globallogic.center.service.DiagnosticService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/diagnostic")
public class DiagnosticController {
	
	@Autowired
	private DiagnosticService diagnosticService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@PostMapping("/save")
	public Diagnostic saveDiagnostic(@RequestBody Diagnostic diagnostic)
	{
		DiagnosticResponse temp = new DiagnosticResponse();
		temp.setCenterName(diagnostic.getCenterName());
		List<Long> list= new ArrayList<Long>();
		
		for(Test test: diagnostic.getTests()) {
			list.add(test.getTestId());
		}
		temp.setTestIds(list);
		
		list= new ArrayList<Long>();
		for(Appointment appointment: diagnostic.getApppointmentList()) {
			list.add(appointment.getAppointmentId());
		}
		temp.setAppointmentIds(list);
		
		diagnosticService.saveDiagnosticResponse(temp);
		diagnostic.setCenterId(temp.getCenterId());
		return diagnostic;
	}
	
	@GetMapping("/get")
	public List<Diagnostic> showDiagnostic()
	{
		List<DiagnosticResponse> list = diagnosticService.getAllCenters();
		List<Diagnostic> listOne = new ArrayList<Diagnostic>();
		for(DiagnosticResponse temp : list)
		{
			Diagnostic diagnostic = new Diagnostic();
			diagnostic.setCenterId(temp.getCenterId());
			diagnostic.setCenterName(temp.getCenterName());
			List<Test> tests = new ArrayList<Test>();
			for(Long centerObj : temp.getTestIds())
			{
				tests.add(restTemplate.getForObject("http://localhost:8111/test/get/" + centerObj,  Test.class));
			}
			diagnostic.setTests(tests);
			diagnostic.getTests();
			
			List<Appointment> appts = new ArrayList<Appointment>();
			for(Long centerOb : temp.getAppointmentIds())
			{
				
				appts.add(restTemplate.getForObject("http://localhost:8222/appoint/show/" + centerOb, Appointment.class));
			}
			diagnostic.setApppointmentList(appts);
			listOne.add(diagnostic);
		}
		return listOne;
	}
	
	@GetMapping("/get/{id}")
	public Diagnostic getCenterById(@PathVariable("id") Long Id)
	{
		DiagnosticResponse temp = diagnosticService.getCenter(Id);
		Diagnostic dObj = new Diagnostic();
		dObj.setCenterId(temp.getCenterId());
		dObj.setCenterName(temp.getCenterName());
		
		List<Test> tests = new ArrayList<Test>();
		for(Long cObj : temp.getTestIds())
		{
			tests.add(restTemplate.getForObject("http://localhost:8111/test/get/" + cObj, Test.class));
		}
		dObj.setTests(tests);
		dObj.getTests();
		
		List<Appointment> appts = new ArrayList<Appointment>();
		for(Long cObje : temp.getAppointmentIds())
		{
			appts.add(restTemplate.getForObject("http://localhost:8222/appoint/show/" + cObje, Appointment.class));
		}
		dObj.setApppointmentList(appts);
		return dObj;
	}
	
}
